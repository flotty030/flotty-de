'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function RegisterPage(){
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [role, setRole] = useState<'COMPANY'|'DRIVER'>('COMPANY');
  const [password, setPassword] = useState('');
  const [agree, setAgree] = useState(false);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{t:'error'|'success', m:string} | null>(null);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent){
    e.preventDefault();
    if(!agree){ setMsg({t:'error', m:'Bitte stimmen Sie AGB & Datenschutz zu.'}); return; }
    setMsg(null);
    setLoading(true);
    try{
      const r = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email, companyName: company, role, password })
      });
      const data = await r.json();
      if(!r.ok){ throw new Error(data.error || 'Registrierung fehlgeschlagen'); }
      setMsg({t:'success', m:'Account erstellt – weiterleiten …'});
      router.push('/app');
    }catch(err:any){
      setMsg({t:'error', m: err.message});
    }finally{
      setLoading(false);
    }
  }

  return (
    <div className="grid" style={{maxWidth:520, margin:'40px auto'}}>
      <h1>Registrieren</h1>
      <form className="form card" onSubmit={onSubmit}>
        <div>
          <label htmlFor="email">Geschäftliche E-Mail</label>
          <input id="email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="company">Firmenname</label>
          <input id="company" value={company} onChange={e=>setCompany(e.target.value)} placeholder="z. B. Flotty GmbH" required />
        </div>
        <div>
          <label htmlFor="role">Rolle</label>
          <select id="role" value={role} onChange={e=>setRole(e.target.value as any)}>
            <option value="COMPANY">Unternehmen</option>
            <option value="DRIVER">Fahrer</option>
          </select>
        </div>
        <div>
          <label htmlFor="password">Passwort (min. 8 Zeichen)</label>
          <input id="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required />
        </div>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <input id="agree" type="checkbox" checked={agree} onChange={e=>setAgree(e.target.checked)} />
          <label htmlFor="agree">Ich akzeptiere die <a className="link" href="/agb" target="_blank">AGB</a> und <a className="link" href="/datenschutz" target="_blank">Datenschutz</a>.</label>
        </div>
        {msg && <p className={msg.t}>{msg.m}</p>}
        <button className="btn" disabled={loading}>{loading?'Bitte warten…':'Account anlegen'}</button>
      </form>
      <p className="note">Bereits registriert? <a className="link" href="/login">Zum Login</a></p>
    </div>
  );
}