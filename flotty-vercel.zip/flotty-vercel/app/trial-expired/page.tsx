import Link from "next/link";

export default function TrialExpired(){
  return (
    <div className="grid" style={{maxWidth:560, margin:'60px auto'}}>
      <h1>Testzeitraum abgelaufen</h1>
      <div className="card">
        <p>
          Ihre 3-tägige Testphase ist beendet. Kontaktieren Sie uns für ein Angebot
          oder verlängern Sie die Testphase nach Absprache.
        </p>
        <div style={{display:'flex',gap:12,marginTop:12}}>
          <a className="btn" href="mailto:hello@flotty.de">Angebot anfragen</a>
          <Link className="btn ghost" href="/login">Zurück zum Login</Link>
        </div>
      </div>
    </div>
  );
}