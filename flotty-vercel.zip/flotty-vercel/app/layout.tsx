export const metadata = {
  title: "Flotty – Fuhrparkmanagement für Unternehmen & Fahrer",
  description: "Sparen Sie Zeit & Kosten: Flotty verwaltet Fahrzeuge, Fahrer-Uploads, Wartungen und Kosten. 3 Tage gratis testen – ohne Risiko.",
  icons: [{ rel: "icon", url: "/favicon.ico" }],
  openGraph: {
    title: "Flotty – Fuhrparkmanagement",
    description: "3 Tage gratis testen. Für Unternehmen & Fahrer.",
    url: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
    siteName: "Flotty",
    type: "website"
  }
};

import "./../styles/globals.css";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>
        <div className="container">
          {children}
        </div>
      </body>
    </html>
  );
}