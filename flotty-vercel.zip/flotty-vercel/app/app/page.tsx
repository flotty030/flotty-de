import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export default async function AppPage(){
  const user = await getCurrentUser();
  if(!user){ redirect('/login'); }
  if(user.trialEnd && new Date(user.trialEnd) < new Date()){
    redirect('/trial-expired');
  }
  return (
    <div className="grid" style={{gap:16}}>
      <h1>Willkommen bei Flotty</h1>
      <div className="card">
        <p>Sie sind eingeloggt als <strong>{user.email}</strong> ({user.role}).</p>
        <p>Trial endet am: {user.trialEnd ? new Date(user.trialEnd).toLocaleString('de-DE') : '—'}</p>
        <div style={{display:'flex', gap:12, marginTop:12}}>
          <form action="/api/auth/logout" method="post">
            <button className="btn ghost">Logout</button>
          </form>
        </div>
      </div>
      <div className="note">Hier entsteht Ihre Web-App (Fahrzeuge, Fahrer-Uploads, etc.).</div>
    </div>
  );
}