import Link from "next/link";

export default function Page() {
  return (
    <>
      <header className="sticky">
        <nav>
          <div className="logo">
            <img alt="Flotty Logo" src="/logo.svg" />
            <span>Flotty</span>
            <span className="badge">3 Tage gratis</span>
          </div>
          <div className="right">
            <Link className="btn ghost" href="/login">Login</Link>
            <Link className="btn" href="/register">Registrieren</Link>
          </div>
        </nav>
      </header>

      <section className="hero">
        <h1>Fuhrparkmanagement, das einfach funktioniert.</h1>
        <p>
          Flotty bündelt Fahrzeugverwaltung, Fahrer-Uploads, Wartungspläne und Kostenkontrolle in einer modernen Web-App.
          Für Unternehmen & Fahrer. Starten Sie heute – die ersten 3 Tage sind kostenlos.
        </p>
        <div style={{display:"flex", gap:12, flexWrap:"wrap"}}>
          <Link className="btn" href="/register">Jetzt 3 Tage gratis testen</Link>
          <a className="btn secondary" href="#features">Demo ansehen</a>
        </div>
      </section>

      <div className="sections" id="features">
        <section className="section card">
          <h2>Features</h2>
          <div className="grid two">
            <ul>
              <li>Fahrzeugstammdaten & Dokumente</li>
              <li>Fahrer-Uploads (Fotos, Schäden, Belege)</li>
              <li>Wartungs- & HU-Fristen mit Erinnerungen</li>
            </ul>
            <ul>
              <li>Tanken & Kosten – transparent</li>
              <li>Rollen & Rechte für Teams</li>
              <li>Echtzeit-Übersichten & Export</li>
            </ul>
          </div>
        </section>

        <section className="section card">
          <h2>Für Unternehmen & Fahrer</h2>
          <p className="note">Zwei Perspektiven, ein System – mobil optimiert für den Fahreralltag.</p>
        </section>

        <section className="section card">
          <h2>Preise</h2>
          <div className="pricing grid two">
            <div className="tier card">
              <h3>Starter</h3>
              <p>Ideal zum Testen – <strong>3 Tage gratis</strong>.</p>
              <ul>
                <li>Bis 10 Fahrzeuge</li>
                <li>Basis-Features</li>
              </ul>
              <Link className="btn" href="/register">Kostenlos starten</Link>
            </div>
            <div className="tier card">
              <h3>Business</h3>
              <p>Skalierbar für wachsende Flotten.</p>
              <ul>
                <li>Unbegrenzte Fahrzeuge</li>
                <li>Erweiterte Auswertungen</li>
              </ul>
              <a className="btn ghost" href="#kontakt">Kontakt aufnehmen</a>
            </div>
          </div>
          <p className="note">Nach der Testphase erhalten Sie ein Angebot – keine automatische Abbuchung.</p>
        </section>

        <section id="kontakt" className="section card">
          <h2>Kontakt</h2>
          <p className="note">Fragen? Schreiben Sie uns an <a className="link" href="mailto:hello@flotty.de">hello@flotty.de</a>.</p>
        </section>
      </div>

      <footer className="footer">
        <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:10}}>
          <span>© {new Date().getFullYear()} Flotty</span>
          <div style={{display:"flex",gap:12}}>
            <a className="link" href="/impressum">Impressum</a>
            <a className="link" href="/datenschutz">Datenschutz</a>
          </div>
        </div>
      </footer>
    </>
  );
}