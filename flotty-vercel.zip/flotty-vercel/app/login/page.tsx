'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{t:'error'|'success', m:string} | null>(null);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent){
    e.preventDefault();
    setMsg(null);
    setLoading(true);
    try{
      const r = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email, password })
      });
      const data = await r.json();
      if(!r.ok){ throw new Error(data.error || 'Login fehlgeschlagen'); }
      setMsg({t:'success', m:'Erfolgreich eingeloggt – weiterleiten …'});
      router.push('/app');
    }catch(err:any){
      setMsg({t:'error', m: err.message});
    }finally{
      setLoading(false);
    }
  }

  return (
    <div className="grid" style={{maxWidth:480, margin:'40px auto'}}>
      <h1>Login</h1>
      <form className="form card" onSubmit={onSubmit}>
        <div>
          <label htmlFor="email">E-Mail</label>
          <input id="email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="password">Passwort</label>
          <input id="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        </div>
        {msg && <p className={msg.t}>{msg.m}</p>}
        <button className="btn" disabled={loading}>{loading?'Bitte warten…':'Einloggen'}</button>
      </form>
      <p className="note">Noch keinen Zugang? <a className="link" href="/register">Jetzt registrieren</a></p>
    </div>
  );
}