import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import crypto from "crypto";

export async function POST(req: Request){
  try{
    const { email, password, companyName, role } = await req.json();
    if(!email || !password || !companyName){
      return NextResponse.json({ error: "E-Mail, Passwort und Firmenname sind erforderlich." }, { status: 400 });
    }
    const existing = await prisma.user.findUnique({ where: { email } });
    if(existing){
      return NextResponse.json({ error: "E-Mail bereits registriert." }, { status: 400 });
    }
    const company = await prisma.company.create({ data: { name: companyName } });
    const hash = await bcrypt.hash(password, 10);
    const trialEnd = new Date(Date.now() + 3*24*60*60*1000);
    const user = await prisma.user.create({
      data: {
        email,
        password: hash,
        role: role === 'DRIVER' ? 'DRIVER' : 'COMPANY',
        companyId: company.id,
        trialEnd
      }
    });
    const token = crypto.randomUUID();
    const session = await prisma.session.create({
      data: {
        token,
        userId: user.id,
        expiresAt: new Date(Date.now() + 30*24*60*60*1000) // 30 Tage
      }
    });
    const res = NextResponse.json({ ok: true });
    res.cookies.set('flotty_session', session.token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 30*24*60*60
    });
    return res;
  }catch(e:any){
    console.error(e);
    return NextResponse.json({ error: "Serverfehler." }, { status: 500 });
  }
}