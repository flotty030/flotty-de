import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import crypto from "crypto";

export async function POST(req: Request){
  try{
    const { email, password } = await req.json();
    if(!email || !password){
      return NextResponse.json({ error: "E-Mail und Passwort sind erforderlich." }, { status: 400 });
    }
    const user = await prisma.user.findUnique({ where: { email } });
    if(!user){ return NextResponse.json({ error: "Ungültige Zugangsdaten." }, { status: 400 }); }
    const ok = await bcrypt.compare(password, user.password);
    if(!ok){ return NextResponse.json({ error: "Ungültige Zugangsdaten." }, { status: 400 }); }
    const token = crypto.randomUUID();
    const session = await prisma.session.create({
      data: { token, userId: user.id, expiresAt: new Date(Date.now() + 30*24*60*60*1000) }
    });
    const res = NextResponse.json({ ok: true });
    res.cookies.set('flotty_session', session.token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 30*24*60*60
    });
    return res;
  }catch(e:any){
    console.error(e);
    return NextResponse.json({ error: "Serverfehler." }, { status: 500 });
  }
}