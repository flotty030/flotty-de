import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { cookies } from "next/headers";

export async function POST(){
  const cookieStore = await cookies();
  const token = cookieStore.get('flotty_session')?.value;
  if(token){
    await prisma.session.deleteMany({ where: { token } });
  }
  const res = NextResponse.redirect(new URL('/login', process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'));
  res.cookies.set('flotty_session', '', { path: '/', maxAge: 0 });
  return res;
}