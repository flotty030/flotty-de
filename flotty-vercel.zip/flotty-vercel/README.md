# Flotty – Next.js + Prisma + Vercel Postgres

Produktionsreifes Starter-Template für Landing-Page, Login/Registrierung und 3-Tage-Gratis-Test. Bereit für Deployment auf **Vercel**.

## Schnellstart (lokal)

```bash
npm i
cp .env.example .env
# .env befüllen: DATABASE_URL
npx prisma migrate dev --name init
npm run dev
```
- App: http://localhost:3000

## Deployment auf Vercel

1. Repository zu GitHub/GitLab pushen (oder ZIP hochladen).
2. Auf **Vercel** neues Projekt anlegen und dieses Repo verbinden.
3. In Vercel unter **Storage** eine **Vercel Postgres**-DB erstellen oder alternative Postgres-URL verwenden.
4. **Environment Variables** setzen:
   - `DATABASE_URL` (von Vercel Postgres/Neon)
   - `NEXT_PUBLIC_APP_URL` (z.B. https://flotty.vercel.app)
5. **Build Command**: `npm run build` (standard)
6. **Install Command**: automatisch
7. **Prisma Migrations** ausführen:
   - In Vercel -> Project -> **Functions/Console** oder über **Vercel CLI**:
     ```bash
     npx prisma migrate deploy
     ```
8. Fertig! Routen:
   - `/` Landing-Page
   - `/register` Registrierung (legt Firma + User + 3-Tage-Test an)
   - `/login` Login
   - `/app` Geschützter Bereich
   - `/trial-expired` Hinweis bei abgelaufener Testphase

## Sicherheit & Hinweise
- Passwörter werden mit `bcryptjs` gehasht.
- Session-Cookie `flotty_session` ist HttpOnly & Secure.
- Für produktive Nutzung empfiehlt sich Rate Limiting, E-Mail-Verifikation, Passwort-Reset und Audit-Logs.
- DSGVO/Impressum/Datenschutz-Seiten bitte ergänzen.
- Diese App nutzt **Next.js App Router** und **Prisma**.

## Struktur
```
app/
  page.tsx                # Landing
  login/page.tsx          # Login
  register/page.tsx       # Registrierung
  app/page.tsx            # Geschützt
  trial-expired/page.tsx  # Trial abgelaufen
  api/auth/*              # API-Routen
lib/
  prisma.ts
  auth.ts
prisma/
  schema.prisma
styles/
  globals.css
public/
  logo.svg
```